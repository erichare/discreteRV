MakeRV
======

R Package for easy generation of Random Variables